ConsoleLibrary
==============

Windows Command Prompt Interface based on RichTextBox