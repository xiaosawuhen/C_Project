CCHtmlToXaml
=========

HTML to XAML converter for Windows Phone 8.1.

Wrong way if you can use the native runtime. Just use the WebView.
========
