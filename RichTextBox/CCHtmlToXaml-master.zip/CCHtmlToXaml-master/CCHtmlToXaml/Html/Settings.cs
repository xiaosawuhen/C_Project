﻿using System.Windows.Media;

namespace CCHtmlToXaml.Html {
	public sealed class Settings {
		public Color BorderColor { get; set; }
		public string ImageUriPrefix { get; set; }
	}
}
